export default {
  "dev": {
    "username": "A16_MYSQL",
    "password": "CEPA16Batch8",
    "database": "CEPA16",
    "host": "cep-a16-mysql.cbom4fltpgce.us-east-1.rds.amazonaws.com",
    "dialect": "mysql"
  }
}
