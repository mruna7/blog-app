export const getResponseHeaders = () => {
    return {
        'Access-Control-Allow-Origin': '*',
    }
}
