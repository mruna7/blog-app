export class BaseController {
    authorization: any;
}
